#include <gtk/gtk.h>


void
OnConf_Pad1                            (GtkButton       *button,
                                        gpointer         user_data);

void
OnConf_Pad2                            (GtkButton       *button,
                                        gpointer         user_data);

void
OnConf_Key                             (GtkButton       *button,
                                        gpointer         user_data);

void
OnConf_Ok                              (GtkButton       *button,
                                        gpointer         user_data);

void
OnConf_Cancel                          (GtkButton       *button,
                                        gpointer         user_data);

void
OnAbout_Ok                             (GtkButton       *button,
                                        gpointer         user_data);

void
OnCfgFixes                             (GtkButton       *button,
                                        gpointer         user_data);

void
OnDefFast                              (GtkButton       *button,
                                        gpointer         user_data);

void
OnDefNice                              (GtkButton       *button,
                                        gpointer         user_data);

void
OnOk                                   (GtkButton       *button,
                                        gpointer         user_data);

void
OnCancel                               (GtkButton       *button,
                                        gpointer         user_data);
