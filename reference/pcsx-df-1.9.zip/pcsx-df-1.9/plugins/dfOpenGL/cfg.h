#ifndef _GPU_CFG_H_
#define _GPU_CFG_H_

#include "gpu_i.h"

void readconfig(void);
void writeconfig(void);


#endif // _GPU_CFG_H_
