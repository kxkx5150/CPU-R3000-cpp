
extern unsigned char primTableC[256];
extern void (*primTableJ[256])(unsigned char *);
