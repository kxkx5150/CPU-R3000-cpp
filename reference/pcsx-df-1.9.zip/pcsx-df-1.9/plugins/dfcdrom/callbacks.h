#include <gtk/gtk.h>


void
on_cfg_dialog_show                     (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_cfg_cancelbutton_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_cfg_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_abt_okbutton_clicked                (GtkButton       *button,
                                        gpointer         user_data);
